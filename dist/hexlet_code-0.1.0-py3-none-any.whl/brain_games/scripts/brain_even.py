#!/usr/bin/env python3
from brain_games.game_brain_even import start_game


def main():
    print('Welcome to the Brain Games!')
    start_game()


if __name__ == '__main__':
    main()
